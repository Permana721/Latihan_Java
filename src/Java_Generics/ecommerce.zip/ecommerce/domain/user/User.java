package Java_Generics.ecommerce.domain.user;

public class User {
    private int id;
    private String name;
    private String email;
    private int saldo;

    public User(){

    }

    public User(int id, String name, String email, int saldo) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.saldo = 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public void printInfo(){
        System.out.println("Nama: " + name);
        System.out.println("Saldo: " + saldo);
    }
}
